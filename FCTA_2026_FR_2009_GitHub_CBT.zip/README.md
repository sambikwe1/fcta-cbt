# FCTA 2026 Financial Regulations CBT

GitHub Pages-ready static CBT package for the Financial Regulations 2009 FCTA 2026 Promotion Examination.

## Files
- `index.html` — main examination page
- `smartcbt.html` — same CBT page under the requested filename
- `questions.js` — self-contained question database used by the CBT
- `questions.json` — editable JSON question database
- `style.css` — responsive styling

## Current configuration
- 300 MCQs
- 60-minute timer
- A–D options
- Question order randomized for each attempt
- Option order randomized for each attempt
- Candidate Name and Staff ID required
- Department/Unit and Exam Code optional
- Automatic marking
- 50% pass-mark display
- Question navigator
- Mobile-friendly/offline after the page has loaded

## GitHub Pages
1. Create a public GitHub repository, e.g. `fcta-cbt`.
2. Upload all files in this folder.
3. Open **Settings → Pages**.
4. Choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then Save.
6. Your exam can be opened at:
   `https://YOUR-USERNAME.github.io/fcta-cbt/`
   or:
   `https://YOUR-USERNAME.github.io/fcta-cbt/smartcbt.html`

## Important
The question database is based on the saved 300-question randomized Financial Regulations 2009 practice set. Verify the examination content against the official FR 2009 text and applicable FCTA examination instructions before using it as an official examination.
